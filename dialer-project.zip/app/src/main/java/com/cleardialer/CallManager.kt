package com.cleardialer

import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class CallInfo(val state: Int, val number: String, val connectTimeMillis: Long)

data class AudioInfo(val muted: Boolean = false, val speaker: Boolean = false)

object CallManager {
    private val calls = mutableListOf<Call>()
    var service: InCallService? = null

    private val _info = MutableStateFlow<CallInfo?>(null)
    val info: StateFlow<CallInfo?> = _info

    private val _audio = MutableStateFlow(AudioInfo())
    val audio: StateFlow<AudioInfo> = _audio

    private val callback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) = publish()
        override fun onDetailsChanged(call: Call, details: Call.Details) = publish()
    }

    val current: Call?
        get() = calls.firstOrNull { it.state == Call.STATE_RINGING } ?: calls.firstOrNull()

    fun add(call: Call) {
        calls.add(call)
        call.registerCallback(callback)
        publish()
    }

    fun remove(call: Call) {
        call.unregisterCallback(callback)
        calls.remove(call)
        publish()
    }

    private fun publish() {
        val c = current
        _info.value = c?.let {
            CallInfo(
                state = it.state,
                number = it.details.handle?.schemeSpecificPart ?: "",
                connectTimeMillis = it.details.connectTimeMillis
            )
        }
    }

    fun onAudio(s: CallAudioState) {
        _audio.value = AudioInfo(muted = s.isMuted, speaker = s.route == CallAudioState.ROUTE_SPEAKER)
    }

    fun answer() { current?.answer(0) }

    fun hangup() {
        val c = current ?: return
        if (c.state == Call.STATE_RINGING) c.reject(false, null) else c.disconnect()
    }

    fun setMuted(muted: Boolean) { service?.setMuted(muted) }

    fun setSpeaker(on: Boolean) {
        service?.setAudioRoute(
            if (on) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_WIRELESS_OR_EARPIECE
        )
    }

    fun dtmf(c: Char) {
        val call = current ?: return
        call.playDtmfTone(c)
        Handler(Looper.getMainLooper()).postDelayed({ call.stopDtmfTone() }, 150)
    }
}
