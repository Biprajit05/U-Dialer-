package com.cleardialer

import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Green = Color(0xFF22C55E)
val Red = Color(0xFFEF4444)
val Muted = Color(0x99FFFFFF)
val AppBg = Brush.verticalGradient(listOf(Color(0xFF0F1B33), Color(0xFF020617)))

fun ComponentActivity.edgeToEdgeDark() {
    enableEdgeToEdge(
        statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
    )
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Green,
            background = Color(0xFF020617),
            surface = Color(0xFF0F172A)
        ),
        content = content
    )
}

@Composable
fun PhoneIcon(modifier: Modifier = Modifier, rotate: Float = 0f, tint: Color = Color.White) {
    Icon(Icons.Default.Call, contentDescription = null, tint = tint, modifier = modifier.rotate(rotate))
}

@Composable
fun Avatar(label: String, size: Dp, fontSize: TextUnit) {
    val palette = listOf(0xFF6366F1, 0xFF0EA5E9, 0xFF14B8A6, 0xFFF59E0B, 0xFFEC4899, 0xFF8B5CF6)
    val c = Color(palette[(label.hashCode() and 0x7fffffff) % palette.size])
    val letter = label.firstOrNull { it.isLetter() }?.uppercase()
    Box(
        Modifier.size(size).clip(CircleShape).background(c.copy(alpha = 0.85f)),
        contentAlignment = Alignment.Center
    ) {
        if (letter != null) {
            Text(letter, color = Color.White, fontSize = fontSize, fontWeight = FontWeight.Medium)
        } else {
            Icon(Icons.Default.Person, null, tint = Color.White, modifier = Modifier.size(size * 0.5f))
        }
    }
}

@Composable
fun RoundCallButton(color: Color, rotate: Float, label: String?, size: Dp = 72.dp, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(size).clip(CircleShape).background(color).clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            PhoneIcon(Modifier.size(size * 0.42f), rotate)
        }
        if (label != null) {
            Spacer(Modifier.height(8.dp))
            Text(label, color = Muted, fontSize = 13.sp)
        }
    }
}

private val padKeys = listOf(
    "1" to "", "2" to "ABC", "3" to "DEF",
    "4" to "GHI", "5" to "JKL", "6" to "MNO",
    "7" to "PQRS", "8" to "TUV", "9" to "WXYZ",
    "*" to "", "0" to "+", "#" to ""
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DialPad(
    modifier: Modifier = Modifier,
    keySize: Dp = 70.dp,
    onLongZero: (() -> Unit)? = null,
    onKey: (Char) -> Unit
) {
    Column(
        modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        padKeys.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                row.forEach { (digit, letters) ->
                    Box(
                        Modifier
                            .size(keySize)
                            .clip(CircleShape)
                            .background(Color(0x1AFFFFFF))
                            .combinedClickable(
                                onClick = { onKey(digit[0]) },
                                onLongClick = if (digit == "0") onLongZero else null
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(digit, fontSize = 28.sp, color = Color.White, fontWeight = FontWeight.Light)
                            if (letters.isNotEmpty()) {
                                Text(letters, fontSize = 9.sp, color = Muted, letterSpacing = 1.5.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
