package com.cleardialer

import android.os.Bundle
import android.telecom.Call
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class InCallActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Proximity sensor is deliberately never used here: no PROXIMITY_SCREEN_OFF_WAKE_LOCK.
        // The screen also stays on for the whole call.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        edgeToEdgeDark()
        setContent { AppTheme { InCallScreen(onFinish = { finish() }) } }
    }
}

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

@Composable
private fun InCallScreen(onFinish: () -> Unit) {
    val ctx = LocalContext.current
    val live by CallManager.info.collectAsStateWithLifecycle()
    val audio by CallManager.audio.collectAsStateWithLifecycle()

    val last = remember { mutableStateOf<CallInfo?>(null) }
    live?.let { last.value = it }
    val info = last.value

    LaunchedEffect(live == null) {
        if (live == null) {
            delay(800)
            onFinish()
        }
    }

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(500)
            now = System.currentTimeMillis()
        }
    }

    var showPad by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf("") }

    val number = info?.number.orEmpty()
    val name by produceState<String?>(null, number) {
        value = withContext(Dispatchers.IO) { Contacts.lookup(ctx, number) }
    }

    val ended = live == null || (info != null && info.state == Call.STATE_DISCONNECTED)
    val ringing = !ended && info != null && info.state == Call.STATE_RINGING
    val status = when {
        ended -> "Call ended"
        ringing -> "Incoming call"
        info != null && info.state == Call.STATE_ACTIVE -> fmt(now - info.connectTimeMillis)
        info != null && info.state == Call.STATE_HOLDING -> "On hold"
        else -> "Calling…"
    }

    Column(
        Modifier.fillMaxSize().background(AppBg).systemBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(status, color = Muted, fontSize = 16.sp, modifier = Modifier.padding(top = 24.dp))

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            if (showPad && !ended) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        typed.takeLast(14), color = Color.White, fontSize = 28.sp,
                        fontWeight = FontWeight.Light, maxLines = 1,
                        modifier = Modifier.height(40.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    DialPad(keySize = 64.dp) { key ->
                        typed += key
                        CallManager.dtmf(key)
                    }
                }
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Avatar(name ?: number, 120.dp, 48.sp)
                    Spacer(Modifier.height(24.dp))
                    Text(
                        name ?: number.ifBlank { "Unknown" },
                        color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center, maxLines = 2
                    )
                    if (name != null) {
                        Spacer(Modifier.height(6.dp))
                        Text(number, color = Muted, fontSize = 16.sp)
                    }
                }
            }
        }

        if (!ringing && !ended) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Toggle("Mute", audio.muted) { CallManager.setMuted(!audio.muted) }
                Toggle("Keypad", showPad) { showPad = !showPad }
                Toggle("Speaker", audio.speaker) { CallManager.setSpeaker(!audio.speaker) }
            }
            Spacer(Modifier.height(32.dp))
        }

        if (ringing) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                RoundCallButton(Red, 135f, "Decline", 76.dp) { CallManager.hangup() }
                RoundCallButton(Green, 0f, "Answer", 76.dp) { CallManager.answer() }
            }
        } else if (!ended) {
            RoundCallButton(Red, 135f, null, 76.dp) { CallManager.hangup() }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Toggle(label: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(76.dp)
            .clip(CircleShape)
            .background(if (on) Color.White else Color(0x22FFFFFF))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (on) Color(0xFF020617) else Color.White, fontSize = 13.sp)
    }
}
