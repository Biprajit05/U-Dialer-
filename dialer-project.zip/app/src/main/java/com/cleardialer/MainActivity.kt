package com.cleardialer

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.telecom.TelecomManager
import android.text.format.DateUtils
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {

    private var tick by mutableIntStateOf(0)
    private var prefill by mutableStateOf<String?>(null)
    private var isDefault by mutableStateOf(false)

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            refreshDefault()
            tick++
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        edgeToEdgeDark()
        readIntent(intent)

        val wanted = buildList {
            add(Manifest.permission.CALL_PHONE)
            add(Manifest.permission.READ_CALL_LOG)
            add(Manifest.permission.READ_CONTACTS)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (wanted.isNotEmpty()) permLauncher.launch(wanted.toTypedArray())

        setContent {
            AppTheme {
                MainScreen(
                    isDefault = isDefault,
                    prefill = prefill,
                    tick = tick,
                    onSetDefault = { requestDefault() },
                    onCall = { placeCall(it) }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        readIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        refreshDefault()
        tick++
    }

    private fun readIntent(i: Intent?) {
        val data = i?.data
        if (data != null && data.scheme == "tel") {
            prefill = Uri.decode(data.schemeSpecificPart)
        }
    }

    private fun refreshDefault() {
        isDefault = getSystemService(TelecomManager::class.java).defaultDialerPackage == packageName
    }

    private fun requestDefault() {
        val rm = getSystemService(RoleManager::class.java)
        if (rm.isRoleAvailable(RoleManager.ROLE_DIALER)) {
            roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
        }
    }

    private fun placeCall(number: String) {
        if (number.isBlank()) return
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            permLauncher.launch(arrayOf(Manifest.permission.CALL_PHONE))
            return
        }
        val uri = Uri.fromParts("tel", number, null)
        getSystemService(TelecomManager::class.java).placeCall(uri, Bundle())
    }
}

@Composable
private fun MainScreen(
    isDefault: Boolean,
    prefill: String?,
    tick: Int,
    onSetDefault: () -> Unit,
    onCall: (String) -> Unit
) {
    var tab by remember { mutableIntStateOf(0) }
    var number by remember { mutableStateOf("") }

    LaunchedEffect(prefill) {
        if (prefill != null) {
            number = prefill
            tab = 0
        }
    }

    Column(Modifier.fillMaxSize().background(AppBg).systemBarsPadding()) {
        if (!isDefault) DefaultBanner(onSetDefault)
        Box(Modifier.weight(1f)) {
            if (tab == 0) {
                KeypadTab(number, { number = it }, onCall)
            } else {
                RecentsTab(tick, onPick = { number = it; tab = 0 }, onCall = onCall)
            }
        }
        BottomBar(tab) { tab = it }
    }
}

@Composable
private fun DefaultBanner(onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(12.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x1F22C55E))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "Set Clear Dialer as your default phone app to use it for calls.",
            color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(10.dp))
        Button(
            onClick = onClick,
            colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)
        ) { Text("Set") }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun KeypadTab(number: String, onChange: (String) -> Unit, onCall: (String) -> Unit) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                number, color = Color.White,
                fontSize = when {
                    number.length <= 10 -> 40.sp
                    number.length <= 14 -> 32.sp
                    else -> 26.sp
                },
                fontWeight = FontWeight.Light, maxLines = 1, textAlign = TextAlign.Center
            )
        }
        DialPad(onLongZero = { onChange(number + "+") }) { onChange(number + it) }
        Spacer(Modifier.height(18.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(22.dp)
        ) {
            Spacer(Modifier.size(70.dp))
            RoundCallButton(Green, 0f, null, 70.dp) { onCall(number) }
            Box(
                Modifier
                    .size(70.dp)
                    .clip(CircleShape)
                    .combinedClickable(
                        onClick = { if (number.isNotEmpty()) onChange(number.dropLast(1)) },
                        onLongClick = { onChange("") }
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (number.isNotEmpty()) Text("⌫", color = Muted, fontSize = 26.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun RecentsTab(tick: Int, onPick: (String) -> Unit, onCall: (String) -> Unit) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf<List<RecentCall>>(emptyList()) }
    LaunchedEffect(tick) {
        list = withContext(Dispatchers.IO) { CallLogRepo.load(ctx) }
    }
    val allowed = ctx.checkSelfPermission(Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED

    Column(Modifier.fillMaxSize()) {
        Text(
            "Recents", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 8.dp)
        )
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    if (allowed) "No recent calls" else "Allow call log access to see recent calls",
                    color = Muted, fontSize = 15.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(32.dp)
                )
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(list) { c ->
                    RecentRow(c, onPick = { onPick(c.number) }, onCall = { onCall(c.number) })
                }
            }
        }
    }
}

private fun typeLabel(type: Int) = when (type) {
    CallLog.Calls.INCOMING_TYPE -> "↙ Incoming"
    CallLog.Calls.OUTGOING_TYPE -> "↗ Outgoing"
    CallLog.Calls.MISSED_TYPE -> "↙ Missed"
    CallLog.Calls.REJECTED_TYPE -> "Declined"
    CallLog.Calls.BLOCKED_TYPE -> "Blocked"
    CallLog.Calls.VOICEMAIL_TYPE -> "Voicemail"
    else -> "Call"
}

private fun timeLabel(ctx: Context, date: Long): String {
    val flags = if (DateUtils.isToday(date)) {
        DateUtils.FORMAT_SHOW_TIME
    } else {
        DateUtils.FORMAT_SHOW_TIME or DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_ABBREV_ALL
    }
    return DateUtils.formatDateTime(ctx, date, flags)
}

@Composable
private fun RecentRow(c: RecentCall, onPick: () -> Unit, onCall: () -> Unit) {
    val ctx = LocalContext.current
    val missed = c.type == CallLog.Calls.MISSED_TYPE
    val title = c.name ?: c.number.ifBlank { "Unknown" }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onPick).padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(title, 46.dp, 18.sp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title, color = if (missed) Red else Color.White, fontSize = 17.sp,
                fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                "${typeLabel(c.type)} · ${timeLabel(ctx, c.date)}",
                color = Muted, fontSize = 13.sp, maxLines = 1
            )
        }
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(Color(0x2222C55E)).clickable(onClick = onCall),
            contentAlignment = Alignment.Center
        ) {
            PhoneIcon(Modifier.size(20.dp), tint = Green)
        }
    }
}

@Composable
private fun BottomBar(tab: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        NavItem(tab == 0, "Keypad", { onSelect(0) }) { DialpadGlyph(it) }
        NavItem(tab == 1, "Recents", { onSelect(1) }) { ClockGlyph(it) }
    }
}

@Composable
private fun NavItem(selected: Boolean, label: String, onClick: () -> Unit, icon: @Composable (Color) -> Unit) {
    val c = if (selected) Green else Muted
    Column(
        Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 32.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        icon(c)
        Spacer(Modifier.height(4.dp))
        Text(label, color = c, fontSize = 12.sp)
    }
}

@Composable
private fun DialpadGlyph(color: Color) {
    Canvas(Modifier.size(24.dp)) {
        val r = 2.2.dp.toPx()
        val step = size.width / 3
        for (i in 0..2) for (j in 0..2) {
            drawCircle(color, r, Offset(step * (j + 0.5f), step * (i + 0.5f)))
        }
    }
}

@Composable
private fun ClockGlyph(color: Color) {
    Canvas(Modifier.size(24.dp)) {
        val c = center
        val rad = size.minDimension / 2 - 1.dp.toPx()
        val w = 2.dp.toPx()
        drawCircle(color, rad, c, style = Stroke(w))
        drawLine(color, c, Offset(c.x, c.y - rad * 0.55f), w, StrokeCap.Round)
        drawLine(color, c, Offset(c.x + rad * 0.45f, c.y), w, StrokeCap.Round)
    }
}
